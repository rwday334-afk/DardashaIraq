package com.dardasha.iraq

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(16,17,26)
    private val card = Color.rgb(26,28,40)
    private val primary = Color.rgb(124,77,255)
    private val white = Color.WHITE
    private val muted = Color.rgb(167,169,184)
    private var micOn = true
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(22, 28, 22, 12)
        }
        return root
    }

    private fun tv(text: String, size: Float, color: Int = white): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(4, 8, 4, 8)
        }

    private fun button(text: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(primary)
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun card(title: String, sub: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(18, 14, 18, 14)
            addView(tv(title, 20f))
            addView(tv(sub, 14f, muted))
            setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.setMargins(0, 0, 0, 14)
            layoutParams = p
        }

    private fun shell(title: String): LinearLayout {
        val root = base()
        root.addView(tv("دردشه العراق", 28f))
        root.addView(tv(title, 18f, muted))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        nav.addView(button("الغرف") { showHome() }, LinearLayout.LayoutParams(0, 58, 1f))
        nav.addView(button("إنشاء") { createRoom() }, LinearLayout.LayoutParams(0, 58, 1f))
        nav.addView(button("حسابي") { profile() }, LinearLayout.LayoutParams(0, 58, 1f))
        root.addView(nav)
        return root
    }

    private fun showHome() {
        val root = shell("الغرف الصوتية")
        content.addView(tv("الغرف المتاحة الآن", 22f))
        content.addView(card("🇮🇶 سوالف العراق", "12 شخص • صوتي", { room("سوالف العراق") }))
        content.addView(card("🎮 قيمز وشباب", "8 أشخاص • صوتي", { room("قيمز وشباب") }))
        content.addView(card("☕ دردشة ليلية", "25 شخص • صوتي", { room("دردشة ليلية") }))
        content.addView(tv("اضغط على أي غرفة للدخول.", 14f, muted))
        setContentView(root)
    }

    private fun room(name: String) {
        val root = base()
        root.addView(tv("←  $name", 24f))
        root.addView(tv("🟢  12 متصل الآن", 15f, Color.rgb(53,208,127)))

        val people = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(16, 10, 16, 10)
        }
        people.addView(tv("🎙️  علي — يتحدث الآن", 18f))
        people.addView(tv("🎧  سارة", 17f))
        people.addView(tv("🎧  محمد", 17f))
        people.addView(tv("🎧  زهراء", 17f))
        root.addView(people, LinearLayout.LayoutParams(-1, 0, 1f))

        val chat = EditText(this).apply {
            hint = "اكتب رسالة..."
            setHintTextColor(muted)
            setTextColor(white)
            setSingleLine()
            setBackgroundColor(card)
        }
        val send = button("إرسال") {
            Toast.makeText(this, "تم إرسال الرسالة", Toast.LENGTH_SHORT).show()
            chat.text.clear()
        }
        root.addView(chat)
        root.addView(send)

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val mic = button(if (micOn) "🎙️ المايك مفتوح" else "🔇 المايك مكتوم") {
            micOn = !micOn
            (it as MaterialButton).text = if (micOn) "🎙️ المايك مفتوح" else "🔇 المايك مكتوم"
            Toast.makeText(this@MainActivity, if (micOn) "تم فتح المايك" else "تم كتم المايك", Toast.LENGTH_SHORT).show()
        }
        controls.addView(mic, LinearLayout.LayoutParams(0, 58, 1f))
        controls.addView(button("خروج") { showHome() }, LinearLayout.LayoutParams(0, 58, 1f))
        root.addView(controls)
        setContentView(root)
    }

    private fun createRoom() {
        val root = shell("إنشاء غرفة")
        val name = EditText(this).apply {
            hint = "اسم الغرفة"
            setTextColor(white)
            setHintTextColor(muted)
            setSingleLine()
        }
        val desc = EditText(this).apply {
            hint = "وصف مختصر"
            setTextColor(white)
            setHintTextColor(muted)
        }
        content.addView(name)
        content.addView(desc)
        content.addView(button("إنشاء الغرفة") {
            val n = if (name.text.isBlank()) "غرفتي الجديدة" else name.text.toString()
            Toast.makeText(this, "تم إنشاء: $n", Toast.LENGTH_LONG).show()
            room(n)
        })
        setContentView(root)
    }

    private fun profile() {
        val root = shell("حسابي")
        content.addView(ImageView(this).apply { setImageResource(com.dardasha.iraq.R.drawable.ic_logo); adjustViewBounds = true; setPadding(30,20,30,20) })
        content.addView(tv("المستخدم العراقي", 23f))
        content.addView(tv("عضو في دردشه العراق", 15f, muted))
        content.addView(button("تعديل الحساب") { Toast.makeText(this, "واجهة تعديل الحساب", Toast.LENGTH_SHORT).show() })
        content.addView(button("الإعدادات") { Toast.makeText(this, "الإعدادات قريباً", Toast.LENGTH_SHORT).show() })
        setContentView(root)
    }
}
